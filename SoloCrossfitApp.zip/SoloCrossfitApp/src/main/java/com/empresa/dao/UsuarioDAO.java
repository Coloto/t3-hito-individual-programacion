package com.empresa.dao;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.empresa.model.Usuario;

public class UsuarioDAO {
	private String endpoint="jdbc:mysql://localhost:3306/test";
	private String usuario="root";
	private String pass="";
	
////PARADIGMA PROCEDIMENTAL ////
	//Función conectar
	public Connection conectar(){
		Connection connection = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(endpoint, usuario, pass);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return connection;
	}//cierra conectar
	
	
////PARADIGMA PROCEDIMENTAL ////
	//Funcion insertar
	public void insertUsuario(Usuario c) {
        // try-with-resource statement will auto close the connection.
            Connection connection = conectar();
        	PreparedStatement ps;
			try {
				ps = connection.prepareStatement("INSERT INTO solocrossfit_users (id, nombre, plan, competir, peso, horas_extra) VALUES (NULL,?,?,?,?,?);");
				ps.setString(1, c.getNombre());
	            ps.setString(2, c.getPlan());
	            ps.setInt(3, c.getCompetir());
	            ps.setString(4, c.getPeso());
	            ps.setInt(5, c.getHorasExtra());
	            ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    }//cierra insertar
	
	//resto de métodos crud
	
	
////PARADIGMA PROCEDIMENTAL ////
	//Funcion select usuario
	public List <Usuario> selectUsuario() {

        List <Usuario> users = new ArrayList < > ();
        Connection connection = conectar();
    	PreparedStatement ps;
        try {
			ps = connection.prepareStatement("SELECT * FROM solocrossfit_users;");
			ResultSet rs = ps.executeQuery();
	        while (rs.next()) {
	            String nombre = rs.getString("nombre");
	            String plan = rs.getString("plan");
	            int competir = rs.getInt("competir");
	            String peso = rs.getString("peso");
	            int horasExtra = rs.getInt("horas_extra");
	            int precioPlan = 0;
	            int precioHoras = 0;
	            int precioCompetir = 0;
	            int total;
	            String categoria = "";
	            
	            //precio del plan
	            switch (plan) {
	    		case "iniciado":
	    			precioPlan = 25;
	    			break;
	    		case "intermedio":
	    			precioPlan = 30;
	    			break;
	    		case "avanzado":
	    			precioPlan = 35;
	    			break;
	    		}//cierra switch
	            
	            //precio horas
	            switch (horasExtra) {
	    		case 0:
	    			precioHoras = 0;
	    			break;
	    		case 1:
	    			precioHoras = 5;
	    			break;
	    		case 2:
	    			precioHoras = 10;
	    			break;
	    		case 3:
	    			precioHoras = 13;
	    			break;
	    		case 4:
	    			precioHoras = 15;
	    			break;
	    		}//cierra switch
	            
	            //precio competir
	            switch (competir) {
	            case 0:
	            	precioCompetir = 0;
	            	break;
	            case 1:
	            	precioCompetir = 22;
	            	break;
	            }//cierra switch
	            
	            total = precioHoras+precioCompetir+precioPlan;
	            
	            //categoria y peso
	            switch (peso) {
	            case "pluma":
	            	peso = "Menor de 66";
	            	categoria = "pluma";
	            	break;
	            case "ligero":
	            	peso = "67-73";
	            	categoria = "ligero";
	            	break;
	            case "medioLigero":
	            	peso = "74-81";
	            	categoria = "medioLigero";
	            	break;
	            case "medio":
	            	peso = "82-90";
	            	categoria = "medio";
	            	break;
	            case "ligeroPesado":
	            	peso = "91-100";
	            	categoria = "ligeroPesado";
	            	break;
	            case "pesado":
	            	peso = "Mayor de 100";
	            	categoria = "pesado";
	            	break;
	            }
	            
	            users.add(new Usuario(nombre, plan, precioPlan, peso, categoria, precioCompetir, horasExtra, precioHoras, total));
	        }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return users;
    }
}//cierra DAO
