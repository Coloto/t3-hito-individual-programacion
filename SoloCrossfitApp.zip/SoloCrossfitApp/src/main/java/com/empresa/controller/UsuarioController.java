package com.empresa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.empresa.model.Usuario;
import com.empresa.dao.UsuarioDAO;
/**
 * Servlet implementation class UsuarioController
 */
@WebServlet("/")
public class UsuarioController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UsuarioController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
    //// PARADIGMA DIRIGIDO A EVENTOS ////
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getServletPath();
        switch (action) {
		case "/add":
			addUsuario(request, response);
			break;
		case "/update":
			updateUsuario(request, response);
			break;
		case "/delete":
			deleteUsuario(request, response);
			break;
		default:
			listUsuario(request, response);
			break;
		}//cierra switch
	}

	private void listUsuario(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}

	private void deleteUsuario(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}

	private void updateUsuario(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}

	//// PARADIGMA PROCEDIMENTAL ////
	private void addUsuario(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String nombre = request.getParameter("nombre");
		String plan = request.getParameter("plan");
		String competirBool = request.getParameter("competir");
		String peso = request.getParameter("peso");
		int horasExtra = Integer.parseInt(request.getParameter("horasExtra"));
		int competir;
		
		if(plan.equals("iniciado") || competirBool == null){
			competir = 0;
		}else {
			competir = 1;
		}
		
		Usuario usuario = new Usuario(nombre,plan,competir,peso,horasExtra);
		UsuarioDAO dao = new UsuarioDAO();
		dao.insertUsuario(usuario);
		//dao.selectUsuario();
	    try {
			response.sendRedirect("lista-usuarios.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	////PARADIGMA PROCEDIMENTAL ////
	private void listUser(HttpServletRequest request, HttpServletResponse response){
		UsuarioDAO dao = new UsuarioDAO();
        List < Usuario > listaUsuario = dao.selectUsuario();
        request.setAttribute("listaUsuario", listaUsuario);
        RequestDispatcher dispatcher = request.getRequestDispatcher("lista-usuarios.jsp");
        try {
			dispatcher.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	////PARADIGMA DIRIGIDO A EVENTOS ////
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
