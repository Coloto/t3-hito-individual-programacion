package com.empresa.model;

//// PARADIGMA ORIENTADO A OBJETOS //// 
public class Usuario {
	public String nombre;
	public String plan;
	public int competir;
	public String peso;
	public int horasExtra;
	public String categoria;
	public int total;
	public int precioPlan;
	public int precioHoras;
	public int precioCompetir;
	
	//constructor para la función add
	public Usuario(String nombre, String plan, int competir, String peso, int horasExtra) {
		super();
		this.nombre = nombre;
		this.plan = plan;
		this.competir = competir;
		this.peso = peso;
		this.horasExtra = horasExtra;
	}
	
	//constructor para la función select
	public Usuario(String nombre, String plan, int precioPlan, String peso, String categoria, int precioCompetir, int horasExtra, int precioHoras, int total) {
		super();
		this.nombre = nombre;
		this.plan = plan;
		this.peso = peso;
		this.horasExtra = horasExtra;
		this.categoria = categoria;
		this.total = total;
		this.precioPlan = precioPlan;
		this.precioHoras = precioHoras;
		this.precioCompetir = precioCompetir;
	}



	// getters y setters
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getPlan() {
		return plan;
	}

	public void setPlan(String plan) {
		this.plan = plan;
	}

	public int getCompetir() {
		return competir;
	}

	public void setCompetir(int competir) {
		this.competir = competir;
	}

	public String getPeso() {
		return peso;
	}

	public void setPeso(String peso) {
		this.peso = peso;
	}

	public int getHorasExtra() {
		return horasExtra;
	}

	public void setHorasExtra(int horasExtra) {
		this.horasExtra = horasExtra;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getPrecioPlan() {
		return precioPlan;
	}

	public void setPrecioPlan(int precioPlan) {
		this.precioPlan = precioPlan;
	}

	public int getPrecioHoras() {
		return precioHoras;
	}

	public void setPrecioHoras(int precioHoras) {
		this.precioHoras = precioHoras;
	}

	public int getPrecioCompetir() {
		return precioCompetir;
	}

	public void setPrecioCompetir(int precioCompetir) {
		this.precioCompetir = precioCompetir;
	}
	
	

}
