CREATE TABLE `test`.`solocrossfit_users` (
`id` INT NOT NULL AUTO_INCREMENT,
`nombre` VARCHAR(30) NOT NULL , 
`plan` VARCHAR(20) NOT NULL , 
`competir` BOOLEAN NOT NULL , 
`peso` VARCHAR(20) NOT NULL , 
`horas_extra` INT NOT NULL , 
PRIMARY KEY (`id`)) ENGINE = InnoDB;