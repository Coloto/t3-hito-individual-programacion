////Paradigma orientado a objetos ////

    //crear la clase User
    class User{
        constructor(nombre, edad){
            this.nombre = nombre;
            this.edad = edad;
        }
        getNombre(){
            return this.nombre;
        }
        setNombre(nombre){
            this.nombre=nombre;
        }

        saludar(){
            return "Hola "+this.nombre;
        }
        despedir(){
            return "Adios, "+this.nombre;
        }
    }

    //crear instancia de usuario
    const usuario = new User("Paco", 18);

//// Fin paradigma orientado a objetos ////



//// Paradigma procedimental ////
    //Funcion entrenando 
    function entrenando(usuario){
        let mensaje = document.getElementById("entrenando");
        mensaje.innerHTML = usuario.nombre+" está entrenando.";
    }
    //Función cambiar nombre
    function cambiarNombre(nombre){
        usuario.setNombre(nombre);
        entrenando(usuario);
}
//// Fin paradigma procedimental ////



//// Paradigma dirigido a eventos ////
    //Botón saludar 
    function botonSaludar(){
        let saludar = document.getElementById("saludar/despedir");
        saludar.innerHTML = usuario.saludar()+", tienes "+usuario.edad+ " años";
    }
    //Botón despedir
    function botonDespedir(){
        let despedir = document.getElementById("saludar/despedir");
        despedir.innerHTML = usuario.despedir()+", esperamos verte pronto";
    }
    //Botón cambiar nombre
    function botonCambiarNombre(){
        cambiar_nombre("Juan");
    }
//// Fin Paradigma dirigido a eventos ////
entrenando(usuario);